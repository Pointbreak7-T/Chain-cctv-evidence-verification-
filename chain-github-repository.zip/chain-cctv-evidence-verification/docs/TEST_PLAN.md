# Test Plan

These are manual tests for the current browser prototype.

| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Register a video | Select a test video and click **Hash & register** | A SHA-256 hash and local timestamp appear; registered count increments |
| TC-02 | Verify the same file | Register a file, then select the exact same bytes for verification | A match is reported |
| TC-03 | Verify an unregistered file | Select a different file and verify without registering it | No matching record is reported |
| TC-04 | Detect changed content | Register a test file, modify/copy it so bytes differ, and verify the changed file | No matching record is reported |
| TC-05 | Merkle root | Register two or more files and calculate the Merkle root | A deterministic demo root is displayed for the current records |
| TC-06 | Empty ledger | Clear the ledger, then calculate a Merkle root | The UI asks for evidence to be registered first |
| TC-07 | Privacy check | Use browser developer tools/network view while registering a file | The prototype should not send the selected video to a server |
| TC-08 | Session lifecycle | Register a file and refresh the page | In-memory records are cleared |

## Known limitations

- The demo ledger is not persistent and can be cleared by refreshing the page.
- No blockchain node, smart contract, backend API, or trusted timestamp authority is connected.
- The Merkle implementation is for demonstration, not a formal interoperability standard.
- A hash match establishes byte-level consistency with the registered hash, not the original video's real-world authenticity.
- Browser memory requirements may limit hashing very large video files because the prototype reads the file into memory.
