# Architecture and Technical Design

## Scope

This document describes the current browser prototype and a proposed production architecture. Features marked **planned** are not implemented in this repository.

## Current prototype components

- **Browser UI (`index.html`)**: file selection, registration, verification, ledger display, and Merkle-root demonstration.
- **Web Crypto API**: calculates SHA-256 over the selected file bytes.
- **In-memory ledger**: keeps records only for the lifetime of the open page. Refreshing or closing the page clears them.
- **Device clock**: creates a display timestamp; it is not a trusted timestamp authority.
- **Merkle aggregation**: combines registered hex digests into a demonstration root. This is not anchored to a blockchain.

## Current data flow

```mermaid
flowchart TD
    A[CCTV video file selected locally] --> B[Browser reads file bytes]
    B --> C[SHA-256 digest]
    C --> D[Local in-memory evidence record]
    D --> E[Compare digest during verification]
    D --> F[Merkle-root aggregation demo]
    E --> G[Match or no matching record]
```

## Proposed production architecture (planned)

```mermaid
flowchart TD
    A[CCTV recorder / secure ingestion agent] --> B[Authenticated ingestion API]
    B --> C[Secure evidence object storage]
    B --> D[Hashing and signed metadata service]
    D --> E[Append-only evidence database]
    D --> F[Merkle batch builder]
    F --> G[Blockchain anchoring service]
    H[Authorized investigator] --> I[Verification portal]
    I --> C
    I --> E
    I --> G
    I --> J[Recompute hash and compare]
    J --> K[Verification report and audit event]
```

## Example evidence record

The sample JSON in `sample_data/evidence_record.example.json` is illustrative. Production records should include schema version, algorithm identifier, file size, a normalized timestamp, source/device identity where trustworthy, hash, signature information where applicable, and an audit trail. Never treat user-supplied filenames or timestamps as proof of identity or capture time.

## Security and trust boundaries

- Hashing detects content changes relative to a known digest; it cannot establish whether content was authentic before registration.
- A blockchain can make an anchored digest difficult to alter after confirmation; it cannot independently prove that the input video was genuine.
- Trusted timestamps require an appropriate trusted timestamping mechanism or a clearly defined chain-confirmation policy.
- Keep raw video off-chain unless there is a compelling, reviewed reason to do otherwise.
- Production deployment requires authentication, authorization, key management, monitoring, retention controls, backups, and security review.
