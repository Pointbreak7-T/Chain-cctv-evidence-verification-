# .chain — Blockchain-Anchored CCTV Evidence Verification

A privacy-conscious prototype for checking the integrity of CCTV recordings using SHA-256 file hashes, timestamped evidence records, and Merkle-root aggregation.

> **Prototype status:** The browser interface is functional, but its ledger is in-memory and local to the page. It does **not** connect to a real blockchain or provide independently trusted timestamps. Do not present the current demo as production-grade evidence custody.

## Features

- Select a local recording and calculate a SHA-256 fingerprint in the browser.
- Register a local demo record with the device timestamp.
- Verify a selected file against registered hashes.
- Calculate a demonstration Merkle root across registered hashes.
- Keep selected video content in the browser; the prototype does not upload footage.
- Includes architecture notes, sample metadata, test cases, and an MIT license.

## Quick start

### Option A — Open locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Register a video file, then choose the same file under **Verify a recording**.
4. To test tamper detection, make a changed copy of a file and try verifying that copy.

The Web Crypto API is used for SHA-256. If your browser restricts cryptography for local files, serve the folder over localhost instead.

### Option B — Run a local web server
Requires Python 3:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Repository structure

```text
.chain/
├── index.html                 # Interactive browser prototype
├── README.md                  # Setup and project overview
├── LICENSE                    # MIT license
├── docs/
│   ├── ARCHITECTURE.md        # Components, data flow, trust boundaries
│   └── TEST_PLAN.md           # Manual test cases and limitations
├── sample_data/
│   └── evidence_record.example.json
└── tests/
    └── test_vectors.json      # Public SHA-256 test vector
```

## How verification works

1. The browser reads the selected file locally.
2. SHA-256 produces a digest of the file bytes.
3. Registration stores the digest and a device-generated timestamp in the page's memory.
4. Verification recalculates the selected file's digest and compares it with registered digests.
5. Merkle aggregation combines registered hashes into a demo root.

A matching digest means the file's bytes match a registered digest. It does **not**, by itself, prove that the camera recording was genuine, that the original timestamp was accurate, or that chain of custody was maintained before registration.

## Deployment (GitHub Pages)

1. Create a new **public** repository on GitHub named `chain-cctv-evidence-verification`.
2. Upload the files in this repository (including `index.html` at the repository root).
3. Open **Settings → Pages**.
4. Under build/deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish. The public URL will normally look like:
   `https://YOUR-GITHUB-USERNAME.github.io/chain-cctv-evidence-verification/`

Replace `YOUR-GITHUB-USERNAME` with your actual GitHub username. This is a URL pattern, **not a live URL** until you publish the repository.

## Roadmap to a real blockchain-backed system

- Add a backend service and authenticated CCTV ingestion.
- Use durable, access-controlled evidence storage and append-only audit events.
- Anchor hash batches or Merkle roots to a selected blockchain/testnet.
- Use trusted timestamping and signed camera/device identities where available.
- Add role-based investigator access, audit logs, retention policies, and security testing.
- Add server-side verification and independent verification receipts.

## Privacy and safety

The current page processes selected files in the browser and does not intentionally upload them. Use synthetic/test footage during demonstrations and obtain permission before handling real surveillance recordings. Avoid publishing personal or sensitive video files in the repository.

## License

Released under the MIT License; see `LICENSE`.
